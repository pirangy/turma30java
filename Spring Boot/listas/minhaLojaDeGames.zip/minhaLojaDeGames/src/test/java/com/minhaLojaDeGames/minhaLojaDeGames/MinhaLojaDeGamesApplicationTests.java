package com.minhaLojaDeGames.minhaLojaDeGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaLojaDeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
